[{
    "entityUid": "0aa40376-f80f-11ee-ab5f-c4fb9f2bfa62",
    "polygon": {
        "exteriorRing": {
            "points": [
{
          "x": 1.654306116786444,
          "y": 46.889489196592834,
"z": 0,
                "id": 1,
                "type": "LinearRing"
        },
        {
          "x": 1.654287341051717,
          "y": 46.889346219101434,
"z": 0,
                "id": 2,
                "type": "LinearRing"
        },
        {
          "x": 1.653764302726706,
          "y": 46.889278396312,
"z": 0,
                "id": 3,
                "type": "LinearRing"
        },
        {
          "x": 1.6537589382310582,
          "y": 46.889513026137664,
"z": 0,
                "id": 4,
                "type": "LinearRing"
        },
{
          "x": 1.654306116786444,
          "y": 46.889489196592834,
"z": 0,
                "id": 1,
                "type": "LinearRing"
        },

],
            "id": 0,
            "type": "LinearRing"
        },
        "interiorRings": [{
            "points": [],
            "id": 0,
            "type": "LinearRing"
        }],
        "id": 0,
        "type": "LinearRing"
    }
}]

eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlFVWTRNVGxFTTBKQ01ESkRNRFF6TlRrNU5qTXpRVVF4TmpjMU5qaEdOMFl4T1RZeE16WTJNQSJ9.eyJodHRwczovL3NtYWcuYXV0aGVudGljYXRpb24ub3BlcmF0aW9uYWwuY29tL3VzZXJJZCI6IjI1Y2NjYmQzLTQ5ZmEtNDhkMi04OGJhLWJiMzBjMjNmZGVjZiIsImh0dHBzOi8vc21hZy5hdXRoZW50aWNhdGlvbi5vcGVyYXRpb25hbC5jb20vYXBwbGljYXRpb25faWQiOiI4NDNkZjMzZi03NzgxLTQ5YjktODUzNS1lMWZkMDFjY2RlMWQiLCJodHRwczovL3NtYWcuYXV0aGVudGljYXRpb24ub3BlcmF0aW9uYWwuY29tL2VtYWlsIjoiYXBpZGVtb0BzbWFnLnRlY2giLCJpc3MiOiJodHRwczovL3NtYWcuZXUuYXV0aDAuY29tLyIsImF1ZCI6IjhyM29nTjY3NWFMd0dpM0lRZjFUamYxa1pjZFI2bVNRIiwiaWF0IjoxNzEyODQ1NTUwLCJleHAiOjE3MTI4ODg3NTAsInN1YiI6ImF1dGgwfDVlNDUwOWRjODgxYjQ4MGU3MzJmYzFiNyIsImF1dGhfdGltZSI6MTcxMjg0NTU0OSwic2lkIjoiZHN3QVlkd3BpaENzOTJqcjNMYm1yM2p6MmJJb0t6M04ifQ.FQhWHbvow90xhAPhejLKOU8QrYvbW5gcQDHwMGVaF8fuO4F_wMhWBLNCyUuSWHt1-3qWSv3tMSQBhxOjmEq__ZTnTldIK49hbvr3y6TqJLnr7UCM6_LrFSCHn8ELWkn4dc640ysFieQcIeg93o7XFCguF2TfeUfjMMpYGz3q-fBeVoioHLylVYmp7zNpdV6m2ZSXwQ6dIw62G6028FKk5f06tsdGqTH0zvDwP1Br5r1WPbpNwrtkxpiMRnjkXFFHFE0ntbD9fftgRe7uiSfQSv69EyAza84i7uhG4OYcbwfMIntwwFNWx1ndUbCN7Z8Tb66YDbj3kFHpcox4AU7aIQ