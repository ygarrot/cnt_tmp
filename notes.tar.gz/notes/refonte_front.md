nouveau front note;
		endSubscribtion: item.exploitations[0]?.endSubscribtion,
-> on a plusieurs exploits
pareil pour les distributors
## pas besoin de tt le temps fetch ?
![[Pasted image 20240513170736.png]]